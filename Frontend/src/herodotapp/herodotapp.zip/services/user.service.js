"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
require('rxjs/add/operator/map');
var Subject_1 = require('rxjs/Subject');
var userinfo_1 = require('../objects/userinfo');
var UserService = (function () {
    function UserService(http) {
        this.http = http;
        this.isLoggedInSource = new Subject_1.Subject();
    }
    UserService.prototype.getUser = function () {
        return JSON.parse(localStorage.getItem("currentUser"));
    };
    UserService.prototype.logout = function () {
        localStorage.removeItem("currentUser");
        this.isLoggedInSource.next(false);
    };
    UserService.prototype.tryLogin = function (username, password) {
        var _this = this;
        var headers = new http_1.Headers({ 'Content-Type': 'application/json' });
        var options = new http_1.RequestOptions({ headers: headers });
        return this.http.post('http://api.herodot.world/auth', JSON.stringify({ username: username, password: password }), options)
            .map(function (response) {
            console.log("Response => " + response.json());
            var res = response.json();
            if (res && res.token) {
                var userInfo = new userinfo_1.UserInfo();
                userInfo.userName = username;
                userInfo.token = res.token;
                localStorage.setItem('currentUser', JSON.stringify(userInfo));
                _this.isLoggedInSource.next(true);
                return userInfo;
            }
            else {
                return null;
            }
        });
    };
    UserService.prototype.isLoggedIn = function () {
        if (localStorage.getItem("currentUser"))
            return true;
        return false;
    };
    UserService.prototype.loginStatusChanged = function () {
        return this.isLoggedInSource.asObservable();
    };
    UserService.prototype.register = function (model) {
        var headers = new http_1.Headers({ 'Content-Type': 'application/json' });
        var options = new http_1.RequestOptions({ headers: headers });
        return this.http.post('http://api.herodot.world/register', JSON.stringify({ username: model.username, password: model.password, email: model.email }), options);
    };
    UserService.prototype.canActivate = function () {
        return this.isLoggedIn();
    };
    UserService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], UserService);
    return UserService;
}());
exports.UserService = UserService;
//# sourceMappingURL=user.service.js.map