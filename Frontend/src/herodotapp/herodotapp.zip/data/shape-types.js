"use strict";
(function (ShapeType) {
    ShapeType[ShapeType["CIRCLE"] = 0] = "CIRCLE";
})(exports.ShapeType || (exports.ShapeType = {}));
var ShapeType = exports.ShapeType;
//# sourceMappingURL=shape-types.js.map