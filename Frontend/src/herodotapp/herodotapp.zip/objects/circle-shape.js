"use strict";
var CircleShape = (function () {
    function CircleShape() {
    }
    return CircleShape;
}());
exports.CircleShape = CircleShape;
//# sourceMappingURL=circle-shape.js.map