"use strict";
var Geocode = (function () {
    function Geocode() {
    }
    return Geocode;
}());
exports.Geocode = Geocode;
//# sourceMappingURL=geocode.js.map