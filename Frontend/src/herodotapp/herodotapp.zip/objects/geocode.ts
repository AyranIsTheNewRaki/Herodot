export class Geocode{
    lat: number;
    lng: number;
}