"use strict";
var Annotation = (function () {
    function Annotation(data, target) {
        this.data = data;
        this.target = target;
    }
    return Annotation;
}());
exports.Annotation = Annotation;
//# sourceMappingURL=annotation.js.map