export class OperationResponse{
    constructor(public isSuccessfull: boolean, public errorMessage: string = ""){

    }
}