"use strict";
var Shape = (function () {
    function Shape() {
    }
    return Shape;
}());
exports.Shape = Shape;
//# sourceMappingURL=shape.js.map