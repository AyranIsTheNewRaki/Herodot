export class Category {
    topCategory: string;
    displayName: string;
    systemName: string;
    image: string;
}