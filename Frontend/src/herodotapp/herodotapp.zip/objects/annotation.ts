export class Annotation {
  constructor (public data: string, public target: string){ }
}
