export class UserInfo {
    id: number;
    userName: string;
    token: string;
}