"use strict";
var Cho = (function () {
    function Cho() {
    }
    Cho.prototype.requestJson = function () {
        return JSON.stringify({ 'title': this.title, 'description': this.description, 'category': this.category, 'userId': this.userId, 'username': this.username, 'imageUrl': this.imageUrl, 'timeLocations': this.timeLocations.map(function (tl) { return new String(JSON.stringify(tl)); }) });
    };
    Cho.createFromJson = function (js) {
        return new Cho();
    };
    return Cho;
}());
exports.Cho = Cho;
//# sourceMappingURL=cho.js.map