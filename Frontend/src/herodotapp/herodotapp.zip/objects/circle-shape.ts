import { Geocode } from './geocode';

export class CircleShape {
    center: Geocode;
    radius: number;
}