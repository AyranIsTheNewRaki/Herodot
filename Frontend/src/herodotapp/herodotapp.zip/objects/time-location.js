"use strict";
var shape_1 = require('./shape');
var TimeLocation = (function () {
    function TimeLocation() {
        this.name = "";
        this.time = "";
        this.timeType = "";
        this.shape = new shape_1.Shape();
    }
    return TimeLocation;
}());
exports.TimeLocation = TimeLocation;
//# sourceMappingURL=time-location.js.map