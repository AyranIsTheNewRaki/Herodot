"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var ng2_cloudinary_1 = require('ng2-cloudinary');
var categories_1 = require('../../data/categories');
var user_service_1 = require('../../services/user.service');
var alert_service_1 = require('../../services/alert.service');
var maps_service_1 = require('../../services/maps.service');
var cho_service_1 = require('../../services/cho.service');
var cho_1 = require('../../objects/cho');
var time_location_1 = require('../../objects/time-location');
var AddUpdateComponent = (function () {
    function AddUpdateComponent(userService, mapsService, zone, alertService, choService, router) {
        var _this = this;
        this.userService = userService;
        this.mapsService = mapsService;
        this.zone = zone;
        this.alertService = alertService;
        this.choService = choService;
        this.router = router;
        this.categories = categories_1.CATEGORIES;
        this.model = new cho_1.Cho();
        this.loading = false;
        this.uploader = new ng2_cloudinary_1.CloudinaryUploader(new ng2_cloudinary_1.CloudinaryOptions({ cloudName: 'dw5fiolsb', uploadPreset: 'herodot' }));
        mapsService.shapeAdded().subscribe(function (shape) { return _this.addShape(shape); });
        this.model.timeLocations = [];
        this.uploader.onSuccessItem = function (item, response, status, headers) {
            var res = JSON.parse(response);
            _this.imageId = res.public_id;
            _this.model.imageUrl = res.url;
            return { item: item, response: response, status: status, headers: headers };
        };
    }
    AddUpdateComponent.prototype.ngOnInit = function () {
        this.model.username = this.userService.getUser().userName;
        this.model.userId = this.userService.getUser().id;
        this.mapsService.initMap(document.getElementById('map'), false, 51.508742, -0.120850, document.getElementById('mapSearch'));
    };
    AddUpdateComponent.prototype.deleteShape = function (id) {
        for (var i = 0; i < this.model.timeLocations.length; i++) {
            if (this.model.timeLocations[i] && this.model.timeLocations[i].shape.id == id) {
                this.model.timeLocations.splice(i, 1);
                this.mapsService.deleteShape(id);
                break;
            }
        }
        console.log(JSON.stringify(this.model));
    };
    AddUpdateComponent.prototype.addShape = function (shape) {
        var _this = this;
        var timeLocation = new time_location_1.TimeLocation();
        timeLocation.shape = shape;
        this.zone.run(function () { return _this.model.timeLocations.push(timeLocation); });
        console.log(JSON.stringify(this.model));
    };
    AddUpdateComponent.prototype.addCho = function () {
        var _this = this;
        console.log(this.model.userId);
        this.loading = true;
        if (this.model.userId === 0) {
            this.alertService.error("Please select a provider!");
            this.loading = false;
            return;
        }
        this.choService.addCho(this.model).subscribe(function (data) {
            _this.alertService.success("Cho added successfully.", true);
            _this.router.navigate(['categories']);
        }, function (error) {
            _this.alertService.error(JSON.stringify(error));
            _this.loading = false;
        });
    };
    AddUpdateComponent.prototype.upload = function () {
        this.uploader.uploadAll();
    };
    AddUpdateComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'addupdate',
            templateUrl: 'addupdate.component.html'
        }), 
        __metadata('design:paramtypes', [user_service_1.UserService, maps_service_1.MapsService, core_1.NgZone, alert_service_1.AlertService, cho_service_1.ChoService, router_1.Router])
    ], AddUpdateComponent);
    return AddUpdateComponent;
}());
exports.AddUpdateComponent = AddUpdateComponent;
//# sourceMappingURL=addupdate.component.js.map