import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'herodot-annotation',
    templateUrl: 'annotation.component.html'
})
export class AnnotationComponent {
  constructor () {
  }

  ngOnInit () {
  }
}
