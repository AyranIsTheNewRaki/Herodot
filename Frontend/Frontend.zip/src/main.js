"use strict";
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var herodotapp_module_1 = require('./herodotapp/herodotapp.module');
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(herodotapp_module_1.HerodotAppModule);
//# sourceMappingURL=main.js.map