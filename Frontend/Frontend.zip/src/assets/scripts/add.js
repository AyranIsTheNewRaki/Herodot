$(document).ready(function () {
    $('#radio1').click(function () {
        if ($('#radio1').is(':checked') == false) {
            $('#radio1').prop('checked', true);
        } else {
            
        }
    });
    $('#add-image').click(function () {
        $('#add-image-value').trigger('click');
    });
    $('#add-image').change(function () {
        var val = $(this).val();
        var filename = val.replace(/^.*[\\\/]/, '');
        $('label[for="add-image"]').text(filename);
    });
});