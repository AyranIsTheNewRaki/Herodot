import { Component, OnInit } from '@angular/core';

import { CATEGORIES } from '../../data/categories';
import { UserService } from '../../services/user.service';

declare var google: any;

@Component({
    moduleId: module.id,
    selector: 'addupdate',
    templateUrl: 'addupdate.component.html'
})
export class AddUpdateComponent implements OnInit {
    categories = CATEGORIES;
    userName: string;
    constructor(private userService: UserService) {

    }

    ngOnInit() {
        this.userName = this.userService.getUser().userName;
        var mapProp = {
            center: new google.maps.LatLng(51.508742, -0.120850),
            zoom: 5,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            streetViewControl: false
        };
        var map = new google.maps.Map(document.getElementById("map"), mapProp);
        var drawingManager = new google.maps.drawing.DrawingManager();
        drawingManager.setMap(map);
    }

}