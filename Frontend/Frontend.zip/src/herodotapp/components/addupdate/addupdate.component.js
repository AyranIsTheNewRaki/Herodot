"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var categories_1 = require('../../data/categories');
var user_service_1 = require('../../services/user.service');
var AddUpdateComponent = (function () {
    function AddUpdateComponent(userService) {
        this.userService = userService;
        this.categories = categories_1.CATEGORIES;
    }
    AddUpdateComponent.prototype.ngOnInit = function () {
        this.userName = this.userService.getUser().userName;
        var mapProp = {
            center: new google.maps.LatLng(51.508742, -0.120850),
            zoom: 5,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            streetViewControl: false
        };
        var map = new google.maps.Map(document.getElementById("map"), mapProp);
        var drawingManager = new google.maps.drawing.DrawingManager();
        drawingManager.setMap(map);
    };
    AddUpdateComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'addupdate',
            templateUrl: 'addupdate.component.html'
        }), 
        __metadata('design:paramtypes', [user_service_1.UserService])
    ], AddUpdateComponent);
    return AddUpdateComponent;
}());
exports.AddUpdateComponent = AddUpdateComponent;
//# sourceMappingURL=addupdate.component.js.map