import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'main-app',
    templateUrl: 'main.component.html'
})
export class MainComponent {

}