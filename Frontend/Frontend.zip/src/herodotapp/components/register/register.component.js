"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var alert_service_1 = require('../../services/alert.service');
var user_service_1 = require('../../services/user.service');
var userRegistration_1 = require('../../objects/userRegistration');
var RegisterComponent = (function () {
    function RegisterComponent(router, userService, alertService) {
        this.router = router;
        this.userService = userService;
        this.alertService = alertService;
        this.model = new userRegistration_1.UserRegistration();
        this.loading = false;
    }
    RegisterComponent.prototype.register = function () {
        this.loading = true;
        if (this.model.password !== this.model.repassword) {
            this.alertService.error("Passwords do not match!");
            this.loading = false;
            return;
        }
        var registrationResult = this.userService.register(this.model);
        if (registrationResult.isSuccessfull) {
            this.alertService.success("Registration was successfull.", true);
            this.router.navigate(['login']);
        }
        else {
            this.alertService.error(registrationResult.errorMessage);
            this.loading = false;
        }
    };
    RegisterComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'reg,ster',
            templateUrl: 'register.component.html'
        }), 
        __metadata('design:paramtypes', [router_1.Router, user_service_1.UserService, alert_service_1.AlertService])
    ], RegisterComponent);
    return RegisterComponent;
}());
exports.RegisterComponent = RegisterComponent;
//# sourceMappingURL=register.component.js.map