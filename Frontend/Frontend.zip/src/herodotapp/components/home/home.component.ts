import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'herodot-home',
    templateUrl: 'home.component.html'
})
export class HomeComponent {

}