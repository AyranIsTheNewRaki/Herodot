"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var platform_browser_1 = require('@angular/platform-browser');
var forms_1 = require('@angular/forms');
var router_1 = require('@angular/router');
var main_component_1 = require('./components/main/main.component');
var alert_component_1 = require('./components/alert/alert.component');
var header_component_1 = require('./components/header/header.component');
var category_list_component_1 = require('./components/categorylist/category-list.component');
var login_component_1 = require('./components/login/login.component');
var register_component_1 = require('./components/register/register.component');
var addupdate_component_1 = require('./components/addupdate/addupdate.component');
var auth_guard_1 = require('./guards/auth.guard');
var categoryfilter_pipe_1 = require('./pipes/categoryfilter.pipe');
var alert_service_1 = require('./services/alert.service');
var user_service_1 = require('./services/user.service');
var HerodotAppModule = (function () {
    function HerodotAppModule() {
    }
    HerodotAppModule = __decorate([
        core_1.NgModule({
            imports: [
                platform_browser_1.BrowserModule,
                forms_1.FormsModule,
                router_1.RouterModule.forRoot([
                    {
                        path: 'categories',
                        component: category_list_component_1.CategoryListComponent
                    },
                    {
                        path: 'login',
                        component: login_component_1.LoginComponent
                    },
                    {
                        path: 'register',
                        component: register_component_1.RegisterComponent
                    },
                    {
                        path: "addupdate",
                        component: addupdate_component_1.AddUpdateComponent,
                        canActivate: [auth_guard_1.AuthGuard]
                    }
                ])
            ],
            declarations: [main_component_1.MainComponent, alert_component_1.AlertComponent, category_list_component_1.CategoryListComponent, login_component_1.LoginComponent, header_component_1.HeaderComponent, register_component_1.RegisterComponent, addupdate_component_1.AddUpdateComponent, categoryfilter_pipe_1.CategoryFilterPipe],
            bootstrap: [main_component_1.MainComponent],
            providers: [alert_service_1.AlertService, user_service_1.UserService, auth_guard_1.AuthGuard]
        }), 
        __metadata('design:paramtypes', [])
    ], HerodotAppModule);
    return HerodotAppModule;
}());
exports.HerodotAppModule = HerodotAppModule;
//# sourceMappingURL=herodotapp.module.js.map