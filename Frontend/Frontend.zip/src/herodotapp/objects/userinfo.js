"use strict";
var UserInfo = (function () {
    function UserInfo() {
    }
    return UserInfo;
}());
exports.UserInfo = UserInfo;
//# sourceMappingURL=userinfo.js.map