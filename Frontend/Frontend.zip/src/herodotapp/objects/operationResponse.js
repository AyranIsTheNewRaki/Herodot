"use strict";
var OperationResponse = (function () {
    function OperationResponse(isSuccessfull, errorMessage) {
        if (errorMessage === void 0) { errorMessage = ""; }
        this.isSuccessfull = isSuccessfull;
        this.errorMessage = errorMessage;
    }
    return OperationResponse;
}());
exports.OperationResponse = OperationResponse;
//# sourceMappingURL=operationResponse.js.map