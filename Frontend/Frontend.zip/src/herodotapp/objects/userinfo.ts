export class UserInfo {
    userName: string;
    token: string;
}