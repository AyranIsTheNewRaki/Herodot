"use strict";
var UserRegistration = (function () {
    function UserRegistration() {
    }
    return UserRegistration;
}());
exports.UserRegistration = UserRegistration;
//# sourceMappingURL=userRegistration.js.map