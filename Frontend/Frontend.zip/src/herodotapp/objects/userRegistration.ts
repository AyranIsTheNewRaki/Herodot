export class UserRegistration {
    email: string;
    username: string;
    password: string;
    repassword: string;
}