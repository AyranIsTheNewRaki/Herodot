import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { HerodotAppModule } from './herodotapp/herodotapp.module';

platformBrowserDynamic().bootstrapModule(HerodotAppModule);
